# Audio-Spectrum-Analyzer-in-Python
A series of Jupyter notebooks and python files which stream audio from a microphone using pyaudio.

Part 1 is a notebook which streams audio and displays the waveform with matplotlib.

Part 2 adds a spectrum viewer using scipy.fftpack to compute the FFT.
